﻿<#
$userdata = '
$url = "https://experienceazure.blob.core.windows.net/templates/cloudlabs-common/UserDataSample/scripts/psscript-01.ps1" ; $arg= "-AzureUserName amit.kumar@spektrasystems.com -AzurePassword ghghgyg -AzureTenantID ughggughj -AzureSubscriptionID gvgy6755fgg6557hght5 -ODLID 67577 -InstallCloudLabsShadow yes -DeploymentID 757678 -vmAdminUsername demouser -adminPassword Password.1!! -trainerUserName instructor -trainerUserPassword gvhyt76tghfy"'
$Bytes = [System.Text.Encoding]::utf8.GetBytes($userdata)
$EncodedText =[Convert]::ToBase64String($Bytes)
$EncodedText
#>

Start-Transcript -Path C:\WindowsAzure\Logs\userdatalogs.txt -Append
$userData = Invoke-RestMethod -Headers @{"Metadata"="true"} -Method GET -Uri "http://169.254.169.254/metadata/instance/compute/userData?api-version=2021-01-01&format=text"
$decodeduserdata=[System.Text.Encoding]::utf8.GetString([Convert]::FromBase64String($userData))
$decodeduserdata
Invoke-Expression $decodeduserdata

$WebClient = New-Object System.Net.WebClient
$WebClient.DownloadFile("$url","C:\CloudLabs\scripts.ps1")

cd "C:\CloudLabs\"
$runscript = ".\scripts.ps1 $arg"

$runscript

Invoke-Expression $runscript


Disable-ScheduledTask -TaskName "runuserdata" -Confirm:$false


Stop-Transcript